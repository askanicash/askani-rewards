const tasks=document.getElementById('tasks');
for(let i=1;i<=8;i++){
 const b=document.createElement('button');
 b.textContent=`Click Ads ${i} (+${i})`;
 b.onclick=()=>claimTask('ad'+i,i);
 tasks.appendChild(b);
}
function claimTask(id,reward){
 const last=localStorage.getItem(id);
 if(last && Date.now()-Number(last)<12*60*60*1000){
   alert('Wait 12 hours before claiming again');
   return;
 }
 let pts=Number(localStorage.getItem('points')||0);
 pts+=reward;
 localStorage.setItem('points',pts);
 localStorage.setItem(id,Date.now());
 document.getElementById('points').textContent=pts;
 alert('Reward added: '+reward+' points');
}
function withdrawRequest(){
 const pts=Number(localStorage.getItem('points')||0);
 if(pts<100){alert('Minimum 100 points required');return;}
 alert('Withdrawal request submitted (demo)');
}
document.getElementById('points').textContent=localStorage.getItem('points')||0;